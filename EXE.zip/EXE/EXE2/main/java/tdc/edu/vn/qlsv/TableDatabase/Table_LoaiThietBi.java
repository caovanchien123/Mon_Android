package tdc.edu.vn.qlsv.TableDatabase;

public class Table_LoaiThietBi {
    public static final String DB_NAME="dbMaThietBi";
    public static final int VERSION=1;

    public static final String TABLE_NAME="loaiThietBi";
    public static final String KEY_ID="_id";
    public static final String KEY_MALOAI="maLoai";
    public static final String KEY_TENLOAI="tenLoai";
}
