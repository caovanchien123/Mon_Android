package tdc.edu.vn.qlsv.TableDatabase;

public class Table_PhongHoc {
    public static final String DB_NAME="dbPhongHoc";
    public static final int VERSION=1;

    public static final String TABLE_NAME="PhongHoc";
    public static final String KEY_ID="_id";
    public static final String KEY_MAPHONG="maPhong";
    public static final String KEY_LOAIPHONG="loaiPhong";
    public static final String KEY_TANG="tang";
}
