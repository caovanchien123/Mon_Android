package tdc.edu.vn.qlsv.TableDatabase;

public class Table_ChiTietSD {
    public static final String DB_NAME="dbChiTiet";
    public static final int VERSION=1;

    public static final String TABLE_NAME="chiTietSD";
    public static final String KEY_ID="_id";
    public static final String KEY_MAPHONG="maPhong";
    public static final String KEY_MATB="maThietBi";
    public static final String KEY_NGAYSD="ngaySuDung";
    public static final String KEY_SOLUONG="soLuong";
}
