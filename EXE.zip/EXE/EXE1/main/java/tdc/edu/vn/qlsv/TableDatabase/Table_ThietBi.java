package tdc.edu.vn.qlsv.TableDatabase;

public class Table_ThietBi {
    public static final String DB_NAME="dbThietBi";
    public static final int VERSION=1;

    public static final String TABLE_NAME="thietBi";
    public static final String KEY_ID="_id";
    public static final String KEY_MATB="maThietBi";
    public static final String KEY_TENTB="tenThietBi";
    public static final String KEY_XUATXU="xuatXu";
    public static final String KEY_MALOAI="maLoai";
}
