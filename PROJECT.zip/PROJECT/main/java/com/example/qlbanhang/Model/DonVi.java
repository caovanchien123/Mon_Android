package com.example.qlbanhang.Model;

public class DonVi {
    String ten;
    int hinh;

    public DonVi(String ten, int hinh) {
        this.ten = ten;
        this.hinh = hinh;
    }

    public String getTen() {
        return ten;
    }

    public int getHinh() {
        return hinh;
    }
}
